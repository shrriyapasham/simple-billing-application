# Simple Billing Application (BillingPro)

A full-stack, production-grade billing and invoice management application built with **React**, **Spring Boot**, and **persistent H2 Database**.

---

## 1. Project Overview & Features
- **Customer Information Management**: Capture customer name with strict validation.
- **Product Catalog**: Live database-seeded products loaded dynamically from the backend REST API.
- **Dynamic Invoice Line Items**: Add, adjust quantity with +/- buttons, and delete line items with real-time subtotal calculation.
- **Business Discount Rule**: Automatic 10% discount applied strictly when the order subtotal is **greater than ₹1,000**. Subtotals of ₹1,000 or below receive 0% discount.
- **Persistent Database Storage**: Uses file-based H2 storage (`./data/billingdb`) so invoices and products are preserved across server restarts.
- **Invoice History & Search**: Search previous invoices by Customer Name or Invoice Number (`INV-YYYYMMDD-XXXX`).
- **Statistical Summary**: Live dashboard cards showing Total Invoices, Total Revenue, Total Discounts Given, and Average Invoice Value.
- **Print & Download Invoices**: Professional, print-ready invoices (`window.print()` with `@media print` layout) and downloadable text receipts.
- **Standardized Validation & Error Handling**: Comprehensive validation on both frontend and backend with standardized HTTP 400 error responses.

---

## 2. Technology Stack

### Backend
- **Framework**: Spring Boot 3.3.5
- **Language**: Java 17
- **Database**: H2 Database (File-based persistent mode)
- **Data Access**: Spring Data JPA / Hibernate ORM
- **Validation**: Jakarta Bean Validation
- **Testing**: JUnit 5, Spring Boot Test, AssertJ
- **Build Tool**: Apache Maven (wrapper included)

### Frontend
- **Framework**: React 18 (using Vite 5)
- **HTTP Client**: Axios
- **Styling**: Vanilla CSS3 (Custom Responsive Layout, Modern Color Palette, Print-Optimized `@media print`)
- **Runtime**: Node.js 18+ & npm

---

## 3. Project Folder Structure

```text
simple-billing-application/
├── .gitignore                          # Root Git ignore rules
├── README.md                           # Documentation & execution guide
├── simple-billing-application-backup.zip # Project ZIP backup
│
├── .vscode/                            # Visual Studio Code configuration
│   └── extensions.json                 # Recommended extensions (Java, Spring, React)
│
├── backend/                            # Spring Boot Backend
│   ├── .gitignore                      # Backend Git ignore rules
│   ├── mvnw.cmd                        # Maven wrapper script for Windows
│   ├── pom.xml                         # Maven dependencies & build configuration
│   ├── run-backend.bat                 # One-click startup batch script
│   │
│   ├── data/                           # Persistent Database Folder
│   │   └── billingdb.mv.db             # File-based H2 Database storage
│   │
│   └── src/
│       ├── main/
│       │   ├── java/com/example/billing/
│       │   │   ├── ApiExceptionHandler.java   # Global REST exception handler (@RestControllerAdvice)
│       │   │   ├── BillDtos.java             # Request & Response records with validations
│       │   │   ├── BillingApplication.java   # Main Spring Boot entry point
│       │   │   ├── BillingController.java    # REST Controller endpoints (/api/products, /api/invoices)
│       │   │   ├── BillService.java          # Core business logic & discount calculation
│       │   │   ├── DataSeeder.java           # Initial product catalog seeding
│       │   │   ├── Invoice.java              # JPA Entity for Invoice records
│       │   │   ├── InvoiceItem.java          # JPA Entity for Invoice line items
│       │   │   ├── InvoiceRepository.java    # JPA Repository with custom search query
│       │   │   ├── Product.java              # JPA Entity for Products
│       │   │   └── ProductRepository.java    # JPA Repository for Products
│       │   │
│       │   └── resources/
│       │       └── application.properties    # Production & database configuration
│       │
│       └── test/
│           ├── java/com/example/billing/
│           │   └── BillServiceTest.java      # Comprehensive automated unit & integration tests
│           │
│           └── resources/
│               └── application.properties    # In-memory test database configuration
│
└── frontend/                           # React + Vite Frontend
    ├── .gitignore                      # Frontend Git ignore rules
    ├── index.html                      # HTML5 entry page
    ├── package.json                    # Dependencies & NPM scripts
    ├── package-lock.json               # Locked dependency tree
    ├── vite.config.js                  # Vite configuration & backend /api reverse proxy
    └── src/
        ├── App.jsx                     # Complete Billing Dashboard & History component
        ├── main.jsx                    # React root bootstrap
        └── styles.css                  # Modern UI, responsive dashboard, and print styles
```

---

## 4. Opening in Visual Studio Code

1. Launch **Visual Studio Code**.
2. Click **File → Open Folder...** (or press `Ctrl + K`, `Ctrl + O`).
3. Select the folder:
   ```text
   C:\Users\Dell\Downloads\simple-billing-application
   ```
4. Visual Studio Code will load both `backend/` and `frontend/` seamlessly.

---

## 5. Database Architecture & Persistence

Invoice and product data are stored using a **persistent file-based H2 database**.

- **Database file location**: `backend/data/billingdb.mv.db`
- **JDBC Connection URL**: `jdbc:h2:file:./data/billingdb;AUTO_SERVER=TRUE`
- **Driver**: `org.h2.Driver`
- **Username**: `sa`
- **Password**: *(blank)*

### How Data Survives Restarts:
Unlike in-memory H2 (`jdbc:h2:mem:...`), the file-based configuration writes all transactions directly to `backend/data/billingdb.mv.db`. When the Spring Boot application restarts:
1. `DataSeeder.java` checks `productRepo.count() == 0`. Since the database file persists, it does not re-seed duplicates.
2. All saved invoices and their line items remain intact and can be browsed in the **Invoice History** page.
3. The `AUTO_SERVER=TRUE` parameter allows external tools (like the H2 Web Console at `http://localhost:8080/h2-console`) to connect concurrently.

---

## 6. How to Run the Application

### A. Run Backend (Spring Boot)
Open a terminal in VS Code or PowerShell:
```powershell
cd backend
.\mvnw.cmd spring-boot:run
```
*(Alternatively, simply double-click `backend\run-backend.bat`)*

- Backend will start on: `http://localhost:8080`
- H2 Web Console: `http://localhost:8080/h2-console`

### B. Run Frontend (React + Vite)
Open a second terminal in VS Code or PowerShell:
```powershell
cd frontend
npm install
npm run dev
```

- Open your browser at: `http://localhost:5173`

---

## 7. REST API Documentation

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/api/products` | Retrieve catalog of all available products |
| `POST` | `/api/bills/validate` | Validate and calculate proposed bill without saving |
| `POST` | `/api/invoices` | Calculate, assign invoice #, and save to database |
| `GET` | `/api/invoices` | List all saved invoices (supports `?search=keyword`) |
| `GET` | `/api/invoices/{id}` | Retrieve full details of an invoice by ID |

---

## 8. Verification & Tests

### Run Backend Unit & Integration Tests:
```powershell
cd backend
.\mvnw.cmd test
```

### Run Frontend Production Build:
```powershell
cd frontend
npm run build
```
